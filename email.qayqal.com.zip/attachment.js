  Swal.fire({
                title: 'FILE LIMIT 5 MB AND ONLY JPG, PNG, PDF ARE ALLOWED',
                type: 'error',
                showCloseButton: true
            })