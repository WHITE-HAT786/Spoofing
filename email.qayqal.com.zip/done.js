Swal.fire({
                title: 'DONE',
                type: 'success',
                showCloseButton: true
            })