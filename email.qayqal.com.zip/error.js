  Swal.fire({
                title: 'ERROR',
                type: 'error',
                showCloseButton: true
            })